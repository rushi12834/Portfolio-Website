(() => {
  "use strict";

  document.querySelectorAll('a[href^="#"]').forEach((link) => {
    link.addEventListener("click", (evt) => {
      const targetId = link.getAttribute("href");
      if (targetId.length <= 1) return;
      const target = document.querySelector(targetId);
      if (!target) return;
      evt.preventDefault();
      target.scrollIntoView({ behavior: "smooth", block: "start" });
    });
  });

  const githubLink = document.getElementById("githubLink");
  if (githubLink) {
    const username = githubLink.dataset.username;
    if (username) githubLink.href = "https://github.com/" + username;
  }
})();
