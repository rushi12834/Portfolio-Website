# Portfolio — Rushikesh Gaikwad

A responsive personal portfolio site built with plain HTML, CSS, and
JavaScript — no frameworks, no build step.

**Live demo:** add your GitHub Pages link here once deployed.

## What's inside

- Hero introduction and quick stats pulled from resume achievements
- Experience timeline
- Project cards (update the links once each project repo is live)
- Skills grouped by category
- Education and contact section

## Before sending this anywhere

Two placeholders need your real info:

1. In `index.html`, each project card's `view repo` link currently points
   to `#`. Once you've pushed Field Log, Student Management System, etc.
   to GitHub, replace those `href="#"` values with the real repo URLs.
2. In `index.html`, the footer GitHub link (`id="githubLink"`) needs
   your actual GitHub username — either edit the `href` directly or add
   `data-username="your-username"` to the link and `app.js` will build
   the URL for you.

## Run it locally

No build step required — open `index.html` directly, or:

```
git clone <your-repo-url>
cd portfolio-website
open index.html
```
